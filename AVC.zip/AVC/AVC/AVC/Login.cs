namespace AVC
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
    }
}
