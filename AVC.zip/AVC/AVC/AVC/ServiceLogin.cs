﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.VisualBasic.ApplicationServices;
using System.Net.Http.Json;
using System.Runtime.InteropServices;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace AVC
{
    public class LoginService
    {
        private readonly HttpClient _httpClient;

        public LoginService()
        {
            // Asegúrate de poner la URL correcta de tu API
            _httpClient = new HttpClient
            {
                BaseAddress = new Uri("https://localhost:7111/") // Cambia por tu URL del Web API
            };
        }

        public async Task<LoginResponse> IngresarAsync(string usuario, string password)
        {
            var login = new LoginRequest
            {
                Usuario = usuario,
                Pass = password
            };

            HttpResponseMessage response = await _httpClient.PostAsJsonAsync("api/Login/Ingresar", login);

            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<LoginResponse>();
            }
            else
            {
                return null; // O maneja el error según sea necesario
            }
        }
    }
}
