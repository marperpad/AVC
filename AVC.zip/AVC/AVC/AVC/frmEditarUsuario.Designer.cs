﻿namespace AVC
{
    partial class frmEditarUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEditarUsuario));
            lblTitulo = new Label();
            lblIdUser = new Label();
            txtIdUser = new TextBox();
            txtUser = new TextBox();
            lblUsuario = new Label();
            txtNombre = new TextBox();
            lblNombre = new Label();
            lblTipoPerfil = new Label();
            cmbTipoPerfil = new ComboBox();
            btnGuardar = new Button();
            txtPassword = new TextBox();
            lblPassword = new Label();
            btnCerrar = new Button();
            SuspendLayout();
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Century Gothic", 13.970149F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTitulo.Location = new Point(118, 20);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(116, 32);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "Usuarios";
            // 
            // lblIdUser
            // 
            lblIdUser.AutoSize = true;
            lblIdUser.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblIdUser.Location = new Point(55, 90);
            lblIdUser.Name = "lblIdUser";
            lblIdUser.Size = new Size(34, 23);
            lblIdUser.TabIndex = 1;
            lblIdUser.Text = "Id:";
            // 
            // txtIdUser
            // 
            txtIdUser.Enabled = false;
            txtIdUser.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtIdUser.Location = new Point(169, 90);
            txtIdUser.Name = "txtIdUser";
            txtIdUser.Size = new Size(228, 32);
            txtIdUser.TabIndex = 2;
            // 
            // txtUser
            // 
            txtUser.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtUser.Location = new Point(169, 234);
            txtUser.Name = "txtUser";
            txtUser.Size = new Size(228, 32);
            txtUser.TabIndex = 10;
            // 
            // lblUsuario
            // 
            lblUsuario.AutoSize = true;
            lblUsuario.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblUsuario.Location = new Point(55, 237);
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Size = new Size(84, 23);
            lblUsuario.TabIndex = 9;
            lblUsuario.Text = "Usuario:";
            // 
            // txtNombre
            // 
            txtNombre.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNombre.Location = new Point(169, 137);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(228, 32);
            txtNombre.TabIndex = 4;
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNombre.Location = new Point(55, 140);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(95, 23);
            lblNombre.TabIndex = 3;
            lblNombre.Text = "Nombre:";
            // 
            // lblTipoPerfil
            // 
            lblTipoPerfil.AutoSize = true;
            lblTipoPerfil.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTipoPerfil.Location = new Point(46, 186);
            lblTipoPerfil.Name = "lblTipoPerfil";
            lblTipoPerfil.Size = new Size(104, 23);
            lblTipoPerfil.TabIndex = 6;
            lblTipoPerfil.Text = "Tipo Perfil:";
            // 
            // cmbTipoPerfil
            // 
            cmbTipoPerfil.FormattingEnabled = true;
            cmbTipoPerfil.Items.AddRange(new object[] { "Administrador", "Vendedor", "Administrativo" });
            cmbTipoPerfil.Location = new Point(169, 184);
            cmbTipoPerfil.Name = "cmbTipoPerfil";
            cmbTipoPerfil.Size = new Size(228, 31);
            cmbTipoPerfil.TabIndex = 7;
            // 
            // btnGuardar
            // 
            btnGuardar.Image = (Image)resources.GetObject("btnGuardar.Image");
            btnGuardar.Location = new Point(214, 349);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(88, 85);
            btnGuardar.TabIndex = 14;
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // txtPassword
            // 
            txtPassword.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPassword.Location = new Point(169, 287);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.Size = new Size(228, 32);
            txtPassword.TabIndex = 12;
            txtPassword.Visible = false;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPassword.Location = new Point(24, 290);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(130, 23);
            lblPassword.TabIndex = 11;
            lblPassword.Text = "Contraseña:";
            lblPassword.Visible = false;
            // 
            // btnCerrar
            // 
            btnCerrar.Image = (Image)resources.GetObject("btnCerrar.Image");
            btnCerrar.Location = new Point(317, 349);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(80, 85);
            btnCerrar.TabIndex = 15;
            btnCerrar.UseVisualStyleBackColor = true;
            btnCerrar.Click += btnCerrar_Click;
            // 
            // frmEditarUsuario
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(481, 490);
            ControlBox = false;
            Controls.Add(btnCerrar);
            Controls.Add(txtPassword);
            Controls.Add(lblPassword);
            Controls.Add(btnGuardar);
            Controls.Add(cmbTipoPerfil);
            Controls.Add(lblTipoPerfil);
            Controls.Add(txtNombre);
            Controls.Add(lblNombre);
            Controls.Add(txtUser);
            Controls.Add(lblUsuario);
            Controls.Add(txtIdUser);
            Controls.Add(lblIdUser);
            Controls.Add(lblTitulo);
            Name = "frmEditarUsuario";
            Text = "Editar Usuario";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        public Label lblTitulo;
        private Label lblIdUser;
        private Label lblUsuario;
        private Label lblNombre;
        private Label lblTipoPerfil;
        private Button btnGuardar;
        public TextBox txtIdUser;
        public TextBox txtPassword;
        public Label lblPassword;
        public TextBox txtUser;
        public TextBox txtNombre;
        public ComboBox cmbTipoPerfil;
        private Button btnCerrar;
    }
}