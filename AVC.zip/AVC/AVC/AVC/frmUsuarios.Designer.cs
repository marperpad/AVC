﻿namespace AVC
{
    partial class frmUsuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUsuarios));
            dgv1 = new DataGridView();
            lblUsuarios = new Label();
            btnAddUser = new Button();
            btnEditUser = new Button();
            btnCerrar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv1).BeginInit();
            SuspendLayout();
            // 
            // dgv1
            // 
            dgv1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv1.Location = new Point(34, 72);
            dgv1.Name = "dgv1";
            dgv1.RowHeadersWidth = 57;
            dgv1.Size = new Size(723, 456);
            dgv1.TabIndex = 0;
            // 
            // lblUsuarios
            // 
            lblUsuarios.AutoSize = true;
            lblUsuarios.Font = new Font("Century Gothic", 16.1194019F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblUsuarios.Location = new Point(331, 32);
            lblUsuarios.Name = "lblUsuarios";
            lblUsuarios.Size = new Size(135, 37);
            lblUsuarios.TabIndex = 1;
            lblUsuarios.Text = "Usuarios";
            // 
            // btnAddUser
            // 
            btnAddUser.Image = (Image)resources.GetObject("btnAddUser.Image");
            btnAddUser.Location = new Point(776, 102);
            btnAddUser.Name = "btnAddUser";
            btnAddUser.Size = new Size(105, 32);
            btnAddUser.TabIndex = 2;
            btnAddUser.UseVisualStyleBackColor = true;
            btnAddUser.Click += btnAddUser_Click;
            // 
            // btnEditUser
            // 
            btnEditUser.Image = (Image)resources.GetObject("btnEditUser.Image");
            btnEditUser.Location = new Point(776, 151);
            btnEditUser.Name = "btnEditUser";
            btnEditUser.Size = new Size(105, 32);
            btnEditUser.TabIndex = 3;
            btnEditUser.UseVisualStyleBackColor = true;
            btnEditUser.Click += btnEditUser_Click;
            // 
            // btnCerrar
            // 
            btnCerrar.Image = (Image)resources.GetObject("btnCerrar.Image");
            btnCerrar.Location = new Point(786, 204);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(83, 77);
            btnCerrar.TabIndex = 4;
            btnCerrar.UseVisualStyleBackColor = true;
            btnCerrar.Click += btnCerrar_Click;
            // 
            // frmUsuarios
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(918, 558);
            ControlBox = false;
            Controls.Add(btnCerrar);
            Controls.Add(btnEditUser);
            Controls.Add(btnAddUser);
            Controls.Add(lblUsuarios);
            Controls.Add(dgv1);
            Name = "frmUsuarios";
            Text = "Usuarios";
            Load += frmUsuarios_Load;
            ((System.ComponentModel.ISupportInitialize)dgv1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgv1;
        private Label lblUsuarios;
        private Button btnAddUser;
        private Button btnEditUser;
        private Button btnCerrar;
    }
}