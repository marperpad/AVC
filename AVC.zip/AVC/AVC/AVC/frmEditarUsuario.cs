﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AVC
{
    public partial class frmEditarUsuario : Form
    {
        public frmEditarUsuario()
        {
            InitializeComponent();
        }

        CUsuarios cuser = new CUsuarios();

        frmUsuarios usuarios = new frmUsuarios();
        //FUNCION PARA MENSAJE DE ERROR
        static void MensajeError(Exception e)
        {
            try
            {
                MessageBox.Show(e.Message, "ERROR DE SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //FUNCION PARA MENSAJES
        static void Mensajes(string mensaje)
        {
            try
            {
                MessageBox.Show(mensaje, "AVISO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtPassword.Visible == false)
                {
                    cuser.IdUser = Convert.ToInt32(txtIdUser.Text);
                    cuser.Nombre = txtNombre.Text;
                    cuser.Usuario = txtUser.Text;
                    cuser.Tipo = cmbTipoPerfil.SelectedItem.ToString();

                    int guardados = 0;
                    guardados = cuser.EditUsuario();
                    if (guardados == 1)
                    {
                        Mensajes("Se actualizarón");
                        usuarios.Show();
                        this.Hide();
                    }
                    else
                    {
                        Mensajes("No se pudo actualizar");
                    }
                }
                else
                {
                    cuser.Nombre = txtNombre.Text;
                    cuser.Usuario = txtUser.Text;
                    cuser.Pass = txtPassword.Text;
                    cuser.Tipo = cmbTipoPerfil.SelectedItem.ToString();

                    int guardados = 0;
                    guardados = cuser.AddUsuario();
                    if (guardados == 1)
                    {
                        Mensajes("Se guardo correctamente");
                        usuarios.Show();
                        this.Hide();
                    }
                    else
                    {
                        Mensajes("No se pudo guardar");
                    }
                }
            }
            catch (Exception ex)
            {
                MensajeError(ex);
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            try
            {
                usuarios.Show();
                this.Hide();
            }
            catch(Exception ex)
            {
                MensajeError(ex);
            }
        }
    }
}
