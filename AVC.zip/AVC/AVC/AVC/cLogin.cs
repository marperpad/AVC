﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AVC
{
    public class cLogin
    {

        public string cadena = "";
        public SqlConnection Conexion = null;

        public cLogin()
        {
            //Cadena de Conexion
            cadena = "Server=DESKTOP-IAJHNNS\\SQLEXPRESS01;Database=AVC;Trusted_Connection=True;";
        }
        //Atributo Id usuario
        private int _IdUser = 0;
        public int IdUser
        {
            get
            {
                return _IdUser;
            }
            set
            {
                _IdUser = value;
            }
        }
        //Atributo Nombre
        private string _Nombre = "";
        public string Nombre
        {
            get
            {
                return _Nombre;
            }
            set
            {
                _Nombre = value;
            }
        }
        //Atributo Tipo
        private string _Tipo = "";
        public string Tipo
        {
            get
            {
                return _Tipo;
            }
            set
            {
                _Tipo = value;
            }
        }
        //Atributo Usuario
        private string _Usuario = "";
        public string Usuario
        {
            get
            {
                return _Usuario;
            }
            set
            {
                _Usuario = value;
            }
        }
        //Atributo Contraseña
        private string _Pass = "";
        public string Pass
        {
            get
            {
                return _Pass;
            }
            set
            {
                _Pass = value;
            }
        }
        private void AbreConexion()
        {
            try
            {
                if (Conexion == null)
                {
                    Conexion = new SqlConnection(cadena);
                    if (Conexion.State != ConnectionState.Open)
                    {
                        Conexion.Open();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void CerrarConexion()
        {
            try
            {
                if (Conexion != null)
                {
                    if (Conexion.State != ConnectionState.Closed)
                    {
                        Conexion.Close();
                    }
                    Conexion.Dispose();
                    Conexion = null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int Ingresar()
        {
            try
            {
                int ingresa = 0;
                AbreConexion();
                string Consulta = " SELECT Id,Nombre,Tipo,Usuario FROM usuarios WHERE Usuario=@Usuario AND Password=@Pass";
                SqlCommand comando = new SqlCommand(Consulta, Conexion);
                comando.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = this._Usuario;
                comando.Parameters.Add("@Pass", SqlDbType.VarChar).Value = this._Pass;
                SqlDataAdapter Adaptador = new SqlDataAdapter(comando);
                DataSet Ds = new DataSet();
                Adaptador.Fill(Ds);
                if (Ds.Tables.Count == 0)
                {
                    ingresa = 0;
                    return ingresa;
                }
                DataTable DT = new DataTable();
                DT = Ds.Tables[0];
                if (DT.Rows.Count == 0)
                {
                    ingresa = 0;
                    return ingresa;
                }
                DataRow Dr = DT.Rows[0];
                this._IdUser = Convert.ToInt32(Dr["ID"].ToString());
                this._Nombre = Dr["Nombre"].ToString();
                this._Tipo = Dr["Tipo"].ToString();
                this._Usuario = Dr["Usuario"].ToString();
                ingresa = 1;
                return ingresa;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CerrarConexion();
            }
        }

    }
}
