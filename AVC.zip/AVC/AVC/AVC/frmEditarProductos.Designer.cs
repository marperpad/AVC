﻿namespace AVC
{
    partial class frmEditarProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEditarProductos));
            lblTitulo = new Label();
            btnCerrar = new Button();
            btnGuardar = new Button();
            txtDescripcion = new TextBox();
            lblDescripcion = new Label();
            lblPrecio = new Label();
            txtIdProducto = new TextBox();
            lblProducto = new Label();
            nudPrecio = new NumericUpDown();
            nudExistencias = new NumericUpDown();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)nudPrecio).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudExistencias).BeginInit();
            SuspendLayout();
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Century Gothic", 13.970149F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTitulo.Location = new Point(125, 18);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(140, 32);
            lblTitulo.TabIndex = 16;
            lblTitulo.Text = "Productos";
            // 
            // btnCerrar
            // 
            btnCerrar.Image = (Image)resources.GetObject("btnCerrar.Image");
            btnCerrar.Location = new Point(246, 292);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(80, 85);
            btnCerrar.TabIndex = 28;
            btnCerrar.UseVisualStyleBackColor = true;
            btnCerrar.Click += btnCerrar_Click;
            // 
            // btnGuardar
            // 
            btnGuardar.Image = (Image)resources.GetObject("btnGuardar.Image");
            btnGuardar.Location = new Point(143, 292);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(88, 85);
            btnGuardar.TabIndex = 27;
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // txtDescripcion
            // 
            txtDescripcion.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtDescripcion.Location = new Point(176, 124);
            txtDescripcion.Name = "txtDescripcion";
            txtDescripcion.Size = new Size(307, 32);
            txtDescripcion.TabIndex = 20;
            // 
            // lblDescripcion
            // 
            lblDescripcion.AutoSize = true;
            lblDescripcion.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDescripcion.Location = new Point(15, 133);
            lblDescripcion.Name = "lblDescripcion";
            lblDescripcion.Size = new Size(128, 23);
            lblDescripcion.TabIndex = 19;
            lblDescripcion.Text = "Descripcion:";
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPrecio.Location = new Point(31, 174);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(75, 23);
            lblPrecio.TabIndex = 23;
            lblPrecio.Text = "Precio:";
            // 
            // txtIdProducto
            // 
            txtIdProducto.Enabled = false;
            txtIdProducto.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtIdProducto.Location = new Point(176, 86);
            txtIdProducto.Name = "txtIdProducto";
            txtIdProducto.Size = new Size(228, 32);
            txtIdProducto.TabIndex = 18;
            // 
            // lblProducto
            // 
            lblProducto.AutoSize = true;
            lblProducto.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblProducto.Location = new Point(62, 95);
            lblProducto.Name = "lblProducto";
            lblProducto.Size = new Size(34, 23);
            lblProducto.TabIndex = 17;
            lblProducto.Text = "Id:";
            // 
            // nudPrecio
            // 
            nudPrecio.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            nudPrecio.Increment = new decimal(new int[] { 1, 0, 0, 131072 });
            nudPrecio.Location = new Point(176, 165);
            nudPrecio.Name = "nudPrecio";
            nudPrecio.Size = new Size(168, 32);
            nudPrecio.TabIndex = 29;
            // 
            // nudExistencias
            // 
            nudExistencias.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            nudExistencias.Location = new Point(178, 209);
            nudExistencias.Name = "nudExistencias";
            nudExistencias.Size = new Size(168, 32);
            nudExistencias.TabIndex = 30;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(34, 218);
            label1.Name = "label1";
            label1.Size = new Size(117, 23);
            label1.TabIndex = 31;
            label1.Text = "Existencias:";
            // 
            // frmEditarProductos
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(524, 450);
            Controls.Add(label1);
            Controls.Add(nudExistencias);
            Controls.Add(nudPrecio);
            Controls.Add(btnCerrar);
            Controls.Add(btnGuardar);
            Controls.Add(txtDescripcion);
            Controls.Add(lblDescripcion);
            Controls.Add(lblPrecio);
            Controls.Add(txtIdProducto);
            Controls.Add(lblProducto);
            Controls.Add(lblTitulo);
            Name = "frmEditarProductos";
            Text = "frmEditarProductos";
            ((System.ComponentModel.ISupportInitialize)nudPrecio).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudExistencias).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        public TextBox txtPassword;
        public Label lblPassword;
        public ComboBox cmbTipoPerfil;
        private Label lblTipoPerfil;
        public TextBox txtDescripcion;
        private Label lblDescripcion;
        public TextBox txtUser;
        private Label lblPrecio;
        public Label lblTitulo;
        private Button btnCerrar;
        private Button btnGuardar;
        public TextBox txtIdProducto;
        private Label lblProducto;
        public NumericUpDown nudPrecio;
        public NumericUpDown nudExistencias;
        private NumericUpDown numericUpDown2;
        private Label label1;
    }
}