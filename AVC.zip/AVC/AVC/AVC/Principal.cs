﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AVC
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }
        frmUsuarios frmusuarios = new frmUsuarios();
        frmProductos frmProductos = new frmProductos();
        //FUNCION PARA MENSAJE DE ERROR
        static void MensajeError(Exception e)
        {
            try
            {
                MessageBox.Show(e.Message, "ERROR DE SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //FUNCION PARA MENSAJES
        static void Mensajes(string mensaje)
        {
            try
            {
                MessageBox.Show(mensaje, "AVISO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void productosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmProductos.Show();
            }
            catch (Exception ex)
            {
                MensajeError(ex);
            }
        }

        private void usuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmusuarios.Show();
            }
            catch (Exception ex)
            {
                MensajeError(ex);
            }
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {
                MensajeError(ex);
            }
        }

        private void Principal_Load(object sender, EventArgs e)
        {
            try
            {
                if (lblPuesto.Text == "Administrador")
                {
                }else if(lblPuesto.Text == "Administrativo")
                {
                    MenuUser.Visible = false;
                }
                else
                {
                    MenuProductos.Visible = false;
                    MenuUser.Visible = false;
                }
            }catch(Exception ex)
            {
                MensajeError(ex);
            }
        }
    }
}
