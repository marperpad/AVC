﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AVC
{
    public partial class frmEditarProductos : Form
    {
        public frmEditarProductos()
        {
            InitializeComponent();
        }
        CProductos cproductos = new CProductos();
        frmProductos frmProductos = new frmProductos();
        //FUNCION PARA MENSAJE DE ERROR
        static void MensajeError(Exception e)
        {
            try
            {
                MessageBox.Show(e.Message, "ERROR DE SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //FUNCION PARA MENSAJES
        static void Mensajes(string mensaje)
        {
            try
            {
                MessageBox.Show(mensaje, "AVISO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (lblTitulo.Text == "Registro Productos")
                {
                    cproductos.IdProductos = Convert.ToInt32(txtIdProducto.Text);
                    cproductos.Descripcion = txtDescripcion.Text;
                    cproductos.Precio = Convert.ToDouble(nudPrecio.Text);
                    cproductos.Existencias = Convert.ToInt32(nudExistencias.Text);

                    int guardados = 0;
                    guardados = cproductos.AddProducto();
                    if (guardados == 1)
                    {
                        Mensajes("Se guardo correctamente");
                        frmProductos.Show();
                        this.Hide();
                    }
                    else
                    {
                        Mensajes("No se pudo guardar");
                    }
                }
                else
                {
                    cproductos.IdProductos = Convert.ToInt32(txtIdProducto.Text);
                    cproductos.Descripcion = txtDescripcion.Text;
                    cproductos.Precio = Convert.ToDouble(nudPrecio.Value);
                    cproductos.Existencias = Convert.ToInt32(nudExistencias.Value);

                    int actualizados = 0;
                    actualizados = cproductos.EditExistencias();
                    if (actualizados == 1)
                    {
                        Mensajes("Se actualizarón");
                        frmProductos.Show();
                        this.Hide();
                    }
                    else
                    {
                        Mensajes("No se pudo actualizar");
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            try
            {
                frmProductos.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MensajeError(ex);
            }
        }
    }
}
