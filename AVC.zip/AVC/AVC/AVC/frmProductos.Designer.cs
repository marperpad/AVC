﻿namespace AVC
{
    partial class frmProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProductos));
            btnCerrar = new Button();
            btnAddExistencias = new Button();
            btnAddProducto = new Button();
            lblProductos = new Label();
            dgv1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgv1).BeginInit();
            SuspendLayout();
            // 
            // btnCerrar
            // 
            btnCerrar.Image = (Image)resources.GetObject("btnCerrar.Image");
            btnCerrar.Location = new Point(764, 180);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(83, 77);
            btnCerrar.TabIndex = 9;
            btnCerrar.UseVisualStyleBackColor = true;
            btnCerrar.Click += btnCerrar_Click;
            // 
            // btnAddExistencias
            // 
            btnAddExistencias.Image = (Image)resources.GetObject("btnAddExistencias.Image");
            btnAddExistencias.Location = new Point(754, 127);
            btnAddExistencias.Name = "btnAddExistencias";
            btnAddExistencias.Size = new Size(105, 47);
            btnAddExistencias.TabIndex = 8;
            btnAddExistencias.UseVisualStyleBackColor = true;
            btnAddExistencias.Click += btnAddExistencias_Click;
            // 
            // btnAddProducto
            // 
            btnAddProducto.Image = (Image)resources.GetObject("btnAddProducto.Image");
            btnAddProducto.Location = new Point(754, 76);
            btnAddProducto.Name = "btnAddProducto";
            btnAddProducto.Size = new Size(105, 45);
            btnAddProducto.TabIndex = 7;
            btnAddProducto.UseVisualStyleBackColor = true;
            btnAddProducto.Click += btnAddProducto_Click;
            // 
            // lblProductos
            // 
            lblProductos.AutoSize = true;
            lblProductos.Font = new Font("Century Gothic", 16.1194019F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblProductos.Location = new Point(309, 8);
            lblProductos.Name = "lblProductos";
            lblProductos.Size = new Size(164, 37);
            lblProductos.TabIndex = 6;
            lblProductos.Text = "Productos";
            // 
            // dgv1
            // 
            dgv1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv1.Location = new Point(12, 48);
            dgv1.Name = "dgv1";
            dgv1.RowHeadersWidth = 57;
            dgv1.Size = new Size(723, 456);
            dgv1.TabIndex = 5;
            // 
            // frmProductos
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(899, 568);
            Controls.Add(btnCerrar);
            Controls.Add(btnAddExistencias);
            Controls.Add(btnAddProducto);
            Controls.Add(lblProductos);
            Controls.Add(dgv1);
            Name = "frmProductos";
            Text = "Productos";
            Load += frmProductos_Load;
            ((System.ComponentModel.ISupportInitialize)dgv1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCerrar;
        private Button btnAddExistencias;
        private Button btnAddProducto;
        private Label lblProductos;
        private DataGridView dgv1;
    }
}