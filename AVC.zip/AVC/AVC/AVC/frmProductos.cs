﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AVC
{
    public partial class frmProductos : Form
    {
        public frmProductos()
        {
            InitializeComponent();
        }
        CProductos cproductos = new CProductos();
        //FUNCION PARA MENSAJE DE ERROR
        static void MensajeError(Exception e)
        {
            try
            {
                MessageBox.Show(e.Message, "ERROR DE SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //FUNCION PARA MENSAJES
        static void Mensajes(string mensaje)
        {
            try
            {
                MessageBox.Show(mensaje, "AVISO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
            }
            catch (Exception ex)
            {
                MensajeError(ex);
            }
        }

        private void frmProductos_Load(object sender, EventArgs e)
        {
            try
            {
                DataSet Ds = new DataSet();
                Ds = cproductos.ConsultaProductos();
                dgv1.DataSource = Ds.Tables[0];
            }
            catch (Exception ex)
            {
                MensajeError(ex);
            }
        }

        private void btnAddProducto_Click(object sender, EventArgs e)
        {
            try
            {
                frmEditarProductos frmEditarProducts = new frmEditarProductos();
                AddOwnedForm(frmEditarProducts);
                frmEditarProducts.lblTitulo.Text = "Registro Productos";
                frmEditarProducts.txtIdProducto.Text = cproductos.IdSiguiente().ToString();
                frmEditarProducts.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MensajeError(ex);
            }
        }

        private void btnAddExistencias_Click(object sender, EventArgs e)
        {
            try
            {

                if (dgv1.SelectedRows.Count > 0)
                {
                    string IdSeleccionado = "";
                    IdSeleccionado = dgv1.SelectedRows[0].Cells["Id"].Value.ToString();

                    frmEditarProductos frmEditarProducts = new frmEditarProductos();
                    frmEditarProducts.txtIdProducto.Text = IdSeleccionado;
                    cproductos.IdProductos = Convert.ToInt32(IdSeleccionado);
                    cproductos.Consulta_Uno();
                    frmEditarProducts.txtDescripcion.Text = cproductos.Descripcion.ToString();
                    frmEditarProducts.nudPrecio.Value = Convert.ToInt32(cproductos.Precio);
                    frmEditarProducts.nudExistencias.Value = Convert.ToInt32(cproductos.Existencias);
                    frmEditarProducts.nudPrecio.Enabled = false;
                    frmEditarProducts.txtDescripcion.Enabled= false;
                    frmEditarProducts.lblTitulo.Text = "Editar Productos";
                    frmEditarProducts.Show();
                    this.Hide();
                }
                else
                {
                    Mensajes("Favor de Seleccionar un registro");
                }
            }
            catch (Exception ex)
            {
                MensajeError(ex);
            }
        }
    }
}
