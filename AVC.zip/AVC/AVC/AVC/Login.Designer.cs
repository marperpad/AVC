﻿using System.Runtime.InteropServices;

namespace AVC
{
    partial class Login
    {

        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblUsuario = new Label();
            txtUsuario = new TextBox();
            btnIngresar = new Button();
            lblPassword = new Label();
            txtPassword = new TextBox();
            SuspendLayout();
            // 
            // lblUsuario
            // 
            lblUsuario.AutoSize = true;
            lblUsuario.Font = new Font("Century Gothic", 13.970149F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblUsuario.Location = new Point(206, 70);
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Size = new Size(106, 32);
            lblUsuario.TabIndex = 0;
            lblUsuario.Text = "Usuario";
            // 
            // txtUsuario
            // 
            txtUsuario.Font = new Font("Century Gothic", 16.1194019F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtUsuario.Location = new Point(337, 63);
            txtUsuario.Name = "txtUsuario";
            txtUsuario.Size = new Size(232, 44);
            txtUsuario.TabIndex = 1;
            // 
            // btnIngresar
            // 
            btnIngresar.Font = new Font("Century Gothic", 13.970149F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnIngresar.Location = new Point(282, 257);
            btnIngresar.Name = "btnIngresar";
            btnIngresar.Size = new Size(196, 57);
            btnIngresar.TabIndex = 4;
            btnIngresar.Text = "Ingresar";
            btnIngresar.UseVisualStyleBackColor = true;
            btnIngresar.Click += this.btnIngresar_Click;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Century Gothic", 13.970149F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPassword.Location = new Point(178, 149);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(134, 32);
            lblPassword.TabIndex = 2;
            lblPassword.Text = "Password";
            // 
            // txtPassword
            // 
            txtPassword.Font = new Font("Century Gothic", 16.1194019F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPassword.Location = new Point(337, 149);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.Size = new Size(232, 44);
            txtPassword.TabIndex = 3;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtPassword);
            Controls.Add(lblPassword);
            Controls.Add(btnIngresar);
            Controls.Add(txtUsuario);
            Controls.Add(lblUsuario);
            Name = "Login";
            Text = "AVC SYSTEM";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblUsuario;
        private TextBox txtUsuario;
        private Button btnIngresar;
        private Label lblPassword;
        private TextBox txtPassword;


        Principal frmPrincipal = new Principal();
        //FUNCION PARA MENSAJE DE ERROR
        static void MensajeError(Exception e)
        {
            try
            {
                MessageBox.Show(e.Message, "ERROR DE SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //FUNCION PARA MENSAJES
        static void Mensajes(string mensaje)
        {
            try
            {
                MessageBox.Show(mensaje, "AVISO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool ValidarCampos()//FUNCION PARA VALIDAR QUE NO SE HAYAN DEJADO LOS CAMPOS VACIOS
        {
            try
            {
                if (txtUsuario.Text.Trim().Equals(""))
                {
                    Mensajes("Favor de especificar el usuario");
                    txtUsuario.Focus();
                    return false;
                }
                if (txtPassword.Text.Trim().Equals(""))
                {
                    Mensajes("Favor de Ingresar la contraseña");
                    txtPassword.Focus();
                    return false;
                }
                else
                    return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //FUNCIÓN PARA INGRESAR
        private  void btnIngresar_Click(object sender, EventArgs e)
        {
            try
            {
                ValidarCampos();//Se valida que los campos esten correctos
                //se instancia la clase c login
                cLogin Loggin = new cLogin();
                int Bandera = 0;//Se crea una variable bander
                Loggin.Usuario = txtUsuario.Text;//Se asigna el valor de txtuser a la propiedad nombre de la clase
                Loggin.Pass = txtPassword.Text;//Se asigna el valor de txtpassword a la propiedad pass de la clase
                Bandera = Loggin.Ingresar();//Se guardá el valor que retorna la función
                if (Bandera != 0)
                {
                    AddOwnedForm(frmPrincipal);
                    frmPrincipal.lblBienvenido.Text = "¡Bienvenido " + Loggin.Nombre + "!";
                    frmPrincipal.lblPuesto.Text = Loggin.Tipo;
                    //Si la bandera es distinta a cero se abre el formulario principal
                    frmPrincipal.Show();
                    this.Hide();
                }
                else
                {
                    //si la bandera es cero se envía mensaje de error
                    Mensajes("Usuario o Contraseña Incorrectos");
                }

            }
            catch (Exception ex)
            {
                MensajeError (ex);
            }
        }
    }
}
