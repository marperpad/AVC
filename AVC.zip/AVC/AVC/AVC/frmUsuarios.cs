﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AVC
{
    public partial class frmUsuarios : Form
    {

        public frmUsuarios()
        {
            InitializeComponent();
        }
        CUsuarios cusers = new CUsuarios();
        //FUNCION PARA MENSAJE DE ERROR
        static void MensajeError(Exception e)
        {
            try
            {
                MessageBox.Show(e.Message, "ERROR DE SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //FUNCION PARA MENSAJES
        static void Mensajes(string mensaje)
        {
            try
            {
                MessageBox.Show(mensaje, "AVISO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void frmUsuarios_Load(object sender, EventArgs e)
        {
            try
            {
                DataSet Ds = new DataSet();
                Ds = cusers.ConsultaUsuarios();
                dgv1.DataSource = Ds.Tables[0];

            }
            catch (Exception ex)
            {
                MensajeError(ex);
            }
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            try
            {

                frmEditarUsuario frmEditUser = new frmEditarUsuario();
                AddOwnedForm(frmEditUser);
                frmEditUser.lblTitulo.Text = "Agregar Usuario";
                frmEditUser.txtIdUser.Text = cusers.IdSiguiente().ToString();
                frmEditUser.lblPassword.Visible = true;
                frmEditUser.txtPassword.Visible = true;
                frmEditUser.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MensajeError(ex);
            }
        }

        private void btnEditUser_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgv1.SelectedRows.Count > 0)
                {
                    string IdSeleccionado = "";
                    IdSeleccionado = dgv1.SelectedRows[0].Cells["Id"].Value.ToString();

                    frmEditarUsuario frmEditUser = new frmEditarUsuario();
                    frmEditUser.txtIdUser.Text = IdSeleccionado;
                    cusers.IdUser = Convert.ToInt32(IdSeleccionado);
                    cusers.Consulta_Uno();
                    frmEditUser.txtNombre.Text = cusers.Nombre.ToString();
                    frmEditUser.txtUser.Text = cusers.Usuario.ToString();
                    frmEditUser.lblPassword.Visible = false;
                    frmEditUser.txtPassword.Visible = false;
                    string tipo = cusers.Tipo.ToString();
                    if (tipo == "Administrador")
                    {
                        frmEditUser.cmbTipoPerfil.SelectedIndex = 0;
                    }
                    else if (tipo == "Vendedor")
                    {
                        frmEditUser.cmbTipoPerfil.SelectedIndex = 1;
                    }
                    else if (tipo == "Administrativo")
                    {
                        frmEditUser.cmbTipoPerfil.SelectedIndex = 1;
                    }
                    else
                    {

                    }
                    frmEditUser.Show();
                    this.Hide();
                }
                else
                {
                    Mensajes("Favor de Seleccionar un registro");
                }
            }
            catch (Exception ex)
            {
                MensajeError(ex);
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
            }
            catch(Exception ex)
            {
                MensajeError(ex);
            }
        }
    }
}
