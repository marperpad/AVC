﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AVC
{
    public class CProductos
    {
        public string cadena = "";
        public SqlConnection Conexion = null;
        public CProductos()
        {
            cadena = "Server=DESKTOP-IAJHNNS\\SQLEXPRESS01;Database=AVC;Trusted_Connection=True;";
        }
        private int _IdProductos = 0;
        public int IdProductos
        {
            get
            {
                return _IdProductos;
            }
            set
            {
                _IdProductos = value;
            }
        }
        private string _Descripcion = "";
        public string Descripcion
        {
            get
            {
                return _Descripcion;
            }
            set
            {
                _Descripcion = value;
            }
        }
        private double _Precio = 0;
        public double Precio
        {
            get
            {
                return _Precio;
            }
            set
            {
                _Precio = value;
            }
        }
        private int _Existencias = 0;
        public int Existencias
        {
            get
            {
                return _Existencias;
            }
            set
            {
                _Existencias = value;
            }
        }
        private void AbreConexion()
        {
            try
            {
                if (Conexion == null)
                {
                    Conexion = new SqlConnection(cadena);
                    if (Conexion.State != ConnectionState.Open)
                    {
                        Conexion.Open();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void CerrarConexion()
        {
            try
            {
                if (Conexion != null)
                {
                    if (Conexion.State != ConnectionState.Closed)
                    {
                        Conexion.Close();
                    }
                    Conexion.Dispose();
                    Conexion = null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet ConsultaProductos()
        {
            try
            {
                AbreConexion();
                DataSet Ds = new DataSet();
                SqlCommand Comando = new SqlCommand("SELECT Id,Descripcion,Precio,Existencias FROM Productos", Conexion);
                SqlDataAdapter Adpatador = new SqlDataAdapter(Comando);
                Adpatador.Fill(Ds);
                return Ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CerrarConexion();
            }
        }
        public int IdSiguiente()
        {
            try
            {
                DataSet Ds = new DataSet();
                AbreConexion();
                string Consulta = "SELECT isnull(max(Id),0)+1 as Id FROM Productos";
                SqlCommand Comando = new SqlCommand(Consulta, Conexion);
                SqlDataAdapter Adaptador = new SqlDataAdapter(Comando);
                Adaptador.Fill(Ds);
                DataRow DR = Ds.Tables[0].Rows[0];
                return Convert.ToInt32(DR["Id"].ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CerrarConexion();
            }
        }
        public int AddProducto()
        {
            try
            {
                int insertados = 0;
                AbreConexion();
                SqlCommand Comando = new SqlCommand("Insertar_Productos", Conexion);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@Descripcion", SqlDbType.VarChar).Value = this._Descripcion;
                Comando.Parameters.Add("@Precio", SqlDbType.Decimal).Value = this._Precio;
                Comando.Parameters.Add("@Existencias", SqlDbType.Int).Value = this._Existencias;
                insertados = Comando.ExecuteNonQuery();
                return insertados;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CerrarConexion();
            }
        }
        public void Consulta_Uno()
        {
            try
            {
                AbreConexion();
                string Consulta = "SELECT Id,Descripcion,Precio,Existencias FROM Productos WHERE Id=@IdProductos";
                SqlCommand Comando = new SqlCommand(Consulta, Conexion);
                Comando.Parameters.Add("@IdProductos", SqlDbType.Int).Value = this._IdProductos;
                SqlDataAdapter Adaptador = new SqlDataAdapter(Comando);
                DataSet Ds = new DataSet();
                Adaptador.Fill(Ds);
                if (Ds.Tables.Count == 0)
                {
                    throw new Exception("No se encontro el registro buscado");
                }
                DataTable DT = new DataTable();
                DT = Ds.Tables[0];
                if (DT.Rows.Count == 0)
                {
                    throw new Exception("No se encontro el registro buscado");
                }
                DataRow Dr = DT.Rows[0];
                this._IdProductos = Convert.ToInt32(Dr["Id"].ToString());
                this._Descripcion = Dr["Descripcion"].ToString();
                this._Precio = Convert.ToDouble(Dr["Precio"].ToString());
                this._Existencias = Convert.ToInt32(Dr["Existencias"].ToString());

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CerrarConexion();
            }
        }

        public int EditExistencias()
        {
            try
            {
                int actualizados = 0;
                AbreConexion();
                SqlCommand Comando = new SqlCommand("EditarExistencias", Conexion);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@IdProducto", SqlDbType.Int).Value = this._IdProductos;
                Comando.Parameters.Add("@Existencias", SqlDbType.Int).Value = this._Existencias;
                actualizados = Comando.ExecuteNonQuery();
                return actualizados;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CerrarConexion();
            }
        }
    }
}
