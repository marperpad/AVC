﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AVC
{
    public class CUsuarios
    {

        public string cadena = "";
        public SqlConnection Conexion = null;

        public CUsuarios()
        {
            cadena = "Server=DESKTOP-IAJHNNS\\SQLEXPRESS01;Database=AVC;Trusted_Connection=True;";
        }
        private int _IdUser = 0;
        public int IdUser
        {
            get
            {
                return _IdUser;
            }
            set
            {
                _IdUser = value;
            }
        }
        private string _Nombre = "";
        public string Nombre
        {
            get
            {
                return _Nombre;
            }
            set
            {
                _Nombre = value;
            }
        }
        private string _Tipo = "";
        public string Tipo
        {
            get
            {
                return _Tipo;
            }
            set
            {
                _Tipo = value;
            }
        }
        private string _Usuario = "";
        public string Usuario
        {
            get
            {
                return _Usuario;
            }
            set
            {
                _Usuario = value;
            }
        }
        private string _Pass = "";
        public string Pass
        {
            get
            {
                return _Pass;
            }
            set
            {
                _Pass = value;
            }
        }
        private void AbreConexion()
        {
            try
            {
                if (Conexion == null)
                {
                    Conexion = new SqlConnection(cadena);
                    if (Conexion.State != ConnectionState.Open)
                    {
                        Conexion.Open();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void CerrarConexion()
        {
            try
            {
                if (Conexion != null)
                {
                    if (Conexion.State != ConnectionState.Closed)
                    {
                        Conexion.Close();
                    }
                    Conexion.Dispose();
                    Conexion = null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet ConsultaUsuarios()
        {
            try
            {
                AbreConexion();
                DataSet Ds = new DataSet();
                SqlCommand Comando = new SqlCommand("SELECT Id,Nombre,Tipo,Usuario FROM Usuarios", Conexion);
                SqlDataAdapter Adpatador = new SqlDataAdapter(Comando);
                Adpatador.Fill(Ds);
                return Ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CerrarConexion();
            }
        }
        public int IdSiguiente()
        {
            try
            {
                DataSet Ds = new DataSet();
                AbreConexion();
                string Consulta = "SELECT isnull(max(Id),0)+1 as Id FROM Usuarios";
                SqlCommand Comando = new SqlCommand(Consulta, Conexion);
                SqlDataAdapter Adaptador=new SqlDataAdapter(Comando);
                Adaptador.Fill(Ds);
                DataRow DR = Ds.Tables[0].Rows[0];
                return Convert.ToInt32(DR["Id"].ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CerrarConexion();
            }
        }

        public int AddUsuario()
        {
            try
            {
                int insertados = 0;
                AbreConexion();
                SqlCommand Comando = new SqlCommand("Insertar_Usuario", Conexion);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@Nombre", SqlDbType.VarChar).Value = this._Nombre;
                Comando.Parameters.Add("@Tipo", SqlDbType.VarChar).Value = this._Tipo;
                Comando.Parameters.Add("@Password", SqlDbType.VarChar).Value = this._Pass;
                Comando.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = this._Usuario;
                insertados = Comando.ExecuteNonQuery();
                return insertados;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                CerrarConexion();
            }
        }
        public void Consulta_Uno()
        {
            try
            {
                AbreConexion();
                string Consulta = "SELECT Id,Usuario,Nombre,Tipo FROM Usuarios WHERE Id=@IdUser";
                SqlCommand Comando = new SqlCommand(Consulta, Conexion);
                Comando.Parameters.Add("@IdUser", SqlDbType.Int).Value = this._IdUser;
                SqlDataAdapter Adaptador = new SqlDataAdapter(Comando);
                DataSet Ds= new DataSet();
                Adaptador.Fill(Ds);
                if (Ds.Tables.Count == 0)
                {
                    throw new Exception("No se encontro el registro buscado");
                }
                DataTable DT = new DataTable();
                DT = Ds.Tables[0];
                if (DT.Rows.Count == 0)
                {
                    throw new Exception("No se encontro el registro buscado");
                }
                DataRow Dr = DT.Rows[0];
                this._IdUser = Convert.ToInt32(Dr["ID"].ToString());
                this._Nombre = Dr["Nombre"].ToString();
                this._Tipo = Dr["Tipo"].ToString();
                this._Usuario = Dr["Usuario"].ToString();

            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                CerrarConexion() ;
            }
        }

        public int EditUsuario()
        {
            try
            {
                int actualizados = 0;
                AbreConexion();
                SqlCommand Comando = new SqlCommand("Modificar_Usuario", Conexion);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@IdUser", SqlDbType.Int).Value = this._IdUser;
                Comando.Parameters.Add("@Nombre", SqlDbType.VarChar).Value = this._Nombre;
                Comando.Parameters.Add("@Tipo", SqlDbType.VarChar).Value = this._Tipo;
                Comando.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = this._Usuario;
                actualizados = Comando.ExecuteNonQuery();
                return actualizados;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CerrarConexion();
            }
        }
    }
}
