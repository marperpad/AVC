﻿namespace AVC
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            menuStrip1 = new MenuStrip();
            MenuUser = new ToolStripMenuItem();
            MenuProductos = new ToolStripMenuItem();
            salirToolStripMenuItem = new ToolStripMenuItem();
            lblBienvenido = new Label();
            lblPuesto = new Label();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(22, 22);
            menuStrip1.Items.AddRange(new ToolStripItem[] { MenuUser, MenuProductos, salirToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(7, 2, 0, 2);
            menuStrip1.Size = new Size(1348, 31);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // MenuUser
            // 
            MenuUser.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            MenuUser.Image = (Image)resources.GetObject("MenuUser.Image");
            MenuUser.Name = "MenuUser";
            MenuUser.Size = new Size(125, 27);
            MenuUser.Text = "Usuarios";
            MenuUser.Click += usuariosToolStripMenuItem_Click;
            // 
            // MenuProductos
            // 
            MenuProductos.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            MenuProductos.Image = (Image)resources.GetObject("MenuProductos.Image");
            MenuProductos.Name = "MenuProductos";
            MenuProductos.Size = new Size(146, 27);
            MenuProductos.Text = "Productos";
            MenuProductos.Click += productosToolStripMenuItem_Click;
            // 
            // salirToolStripMenuItem
            // 
            salirToolStripMenuItem.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Regular, GraphicsUnit.Point, 0);
            salirToolStripMenuItem.Image = (Image)resources.GetObject("salirToolStripMenuItem.Image");
            salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            salirToolStripMenuItem.Size = new Size(86, 27);
            salirToolStripMenuItem.Text = "Salir";
            salirToolStripMenuItem.Click += salirToolStripMenuItem_Click;
            // 
            // lblBienvenido
            // 
            lblBienvenido.AutoSize = true;
            lblBienvenido.Font = new Font("Century Gothic", 18.2686558F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblBienvenido.ForeColor = SystemColors.ActiveCaption;
            lblBienvenido.Location = new Point(390, 279);
            lblBienvenido.Margin = new Padding(4, 0, 4, 0);
            lblBienvenido.Name = "lblBienvenido";
            lblBienvenido.Size = new Size(220, 40);
            lblBienvenido.TabIndex = 1;
            lblBienvenido.Text = "¡Bienvenido!";
            // 
            // lblPuesto
            // 
            lblPuesto.AutoSize = true;
            lblPuesto.Font = new Font("Century Gothic", 10.7462683F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPuesto.ForeColor = SystemColors.ActiveCaption;
            lblPuesto.Location = new Point(1066, 42);
            lblPuesto.Margin = new Padding(4, 0, 4, 0);
            lblPuesto.Name = "lblPuesto";
            lblPuesto.Size = new Size(74, 23);
            lblPuesto.TabIndex = 2;
            lblPuesto.Text = "Puesto";
            // 
            // Principal
            // 
            AutoScaleDimensions = new SizeF(11F, 22F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1348, 742);
            Controls.Add(lblPuesto);
            Controls.Add(lblBienvenido);
            Controls.Add(menuStrip1);
            Font = new Font("Century Gothic", 10.2089548F, FontStyle.Regular, GraphicsUnit.Point, 0);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(4, 3, 4, 3);
            Name = "Principal";
            Text = "Principal";
            Load += Principal_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private ToolStripMenuItem MenuUser;
        private ToolStripMenuItem MenuProductos;
        public MenuStrip menuStrip1;
        public Label lblBienvenido;
        private ToolStripMenuItem salirToolStripMenuItem;
        public Label lblPuesto;
    }
}