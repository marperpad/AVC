﻿using ApiAVC.Modelo;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace ApiAVC.Context
{
    public class ConexionSqlServer:DbContext
    {
        public ConexionSqlServer(DbContextOptions<ConexionSqlServer> options):base(options)
        {
        
        }
        public DbSet<Usuarios>  Usuarios { get; set; }
        public DbSet<Productos> Productos { get; set; }
    }
}
