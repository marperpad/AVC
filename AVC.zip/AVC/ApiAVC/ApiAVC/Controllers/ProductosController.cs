﻿using ApiAVC.Context;
using ApiAVC.Modelo;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

using System.Data;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ApiAVC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductosController : ControllerBase
    {
        private readonly ConexionSqlServer context;
        public ProductosController(ConexionSqlServer context)
        {
            this.context = context;
        }
        // GET: api/<ProductosController>
        [HttpGet]
        public IActionResult Get(int id)
        {
            try
            {
                List<Productos> products = new List<Productos>();
                if(id==0)
                {
                    products=context.Productos.ToList();
                }
                else
                {

                    SqlConnection conexion = (SqlConnection)context.Database.GetDbConnection();
                    SqlCommand comando = conexion.CreateCommand();
                    conexion.Open();
                    comando.CommandType = System.Data.CommandType.StoredProcedure;
                    comando.CommandText = "GetProductoId";
                    comando.Parameters.Add("@Id", System.Data.SqlDbType.Int).Value = id;
                    SqlDataReader reader = comando.ExecuteReader();
                    while (reader.Read())
                    {
                        Productos productos = new Productos();
                        productos.Id = (int)reader["Id"];
                        productos.Descripcion = (string)reader["Descripcion"];
                        productos.Precio = (decimal)reader["Precio"];
                        productos.Existencias = (int)reader["Existencias"];
                        products.Add(productos);
                    }
                    comando.ExecuteReader();
                    conexion.Close();
                }
                return Ok(products);
            }
            catch
            {
                return BadRequest("Error.");
            }
        }
      

     

        // POST api/<ProductosController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<ProductosController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<ProductosController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
